<?php



define('DB_SERVER', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '!@)59380');
define('DB_NAME', 'membership');
